package com.zosh.domain;

public enum PaymentType {
    CARD,UPI,CASH
}
