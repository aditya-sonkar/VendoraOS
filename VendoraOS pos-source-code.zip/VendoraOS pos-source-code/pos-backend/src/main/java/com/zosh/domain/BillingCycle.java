package com.zosh.domain;

public enum BillingCycle {
    MONTHLY,
    YEARLY
}