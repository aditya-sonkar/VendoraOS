package com.zosh.domain;

public enum OrderStatus {
    COMPLETED, PENDING, REFUNDED, CANCELLED

}
