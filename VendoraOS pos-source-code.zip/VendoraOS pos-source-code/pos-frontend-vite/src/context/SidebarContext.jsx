// src/context/SidebarContext.tsx
import React, { createContext} from "react";



export const SidebarContext = createContext(undefined);


