export { default as CustomerSearch } from './CustomerSearch';
export { default as CustomerList } from './CustomerList';
export { default as CustomerDetails } from './CustomerDetails';
export { default as PurchaseHistory } from './PurchaseHistory';
export { default as AddPointsDialog } from './AddPointsDialog';
