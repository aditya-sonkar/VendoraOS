

// This file is deprecated and has been replaced by ProductForm.jsx
// Keeping this file for backward compatibility

import ProductForm from './ProductForm';

const CreateProductForm = (props) => {
  return <ProductForm {...props} />;
};

export default CreateProductForm;